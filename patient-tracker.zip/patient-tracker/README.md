# Patient Tracker (FastAPI + SQLite)

Basit hasta takip sistemi:
- **Hastalar**: oluştur, listele, güncelle, sil
- **Muayeneler (Visits)**: hastaya muayene kaydı ekle/listede
- **İlaçlar (Medications)**: hastaya ilaç ekle/listele
- **CSV hasta importu** (opsiyonel)

## Kurulum
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Arayüz (Swagger): http://127.0.0.1:8000/docs

## Örnek İstekler

### Hasta oluştur
```bash
curl -X POST http://127.0.0.1:8000/patients   -H "Content-Type: application/json"   -d '{
    "first_name":"Ali",
    "last_name":"Veli",
    "national_id":"12345678901",
    "date_of_birth":"1990-01-01",
    "phone":"+90 555 000 00 00",
    "email":"ali@example.com",
    "address":"Istanbul"
  }'
```

### Arama / listeleme
```
GET /patients?q=ali
```

### Muayene ekle
```
POST /patients/1/visits
{
  "complaint": "Boğaz ağrısı",
  "diagnosis": "Farenjit şüphesi",
  "notes": "Dinlenme + sıvı"
}
```

### İlaç ekle
```
POST /patients/1/medications
{
  "name": "Parasetamol",
  "dosage": "500mg 1x3",
  "start_date": "2025-08-13",
  "instructions": "Tok karnına"
}
```

### CSV import
```
POST /import/patients  (multipart/form-data, file alanı ile)
```

## Notlar
- Varsayılan veritabanı: `patient_tracker.db` (SQLite)
- Model/şema ayrımı yapıldı; ileride Postgres/MariaDB’ye geçiş kolay.
- Kimlik doğrulama yoktur; istenirse JWT/role-based ekleyebiliriz.
